<?php
$zipFile = 'website.rar'; // اسم الملف المضغوط
$extractPath = '.';       // النقطة تعني نفس المجلد (public_html)

$zip = new ZipArchive;
if ($zip->open($zipFile) === TRUE) {
    $zip->extractTo($extractPath);
    $zip->close();
    echo "✅ تم فك الضغط للملف $zipFile بنجاح!<br>";
    echo "📂 الملفات تم استخراجها في: " . realpath($extractPath);
} else {
    echo "❌ فشل في فتح الملف: $zipFile";
}
?>
